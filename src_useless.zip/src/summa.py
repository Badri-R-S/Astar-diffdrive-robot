import pygame
import numpy as np
import math

# Initialize pygame
pygame.init()

# Set the size of the display window
screen_width = 500
screen_height = 500
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Robot Path")

# Define colors
black = (0, 0, 0)
white = (255, 255, 255)
blue = (0, 0, 255)

def plot_curve(Xi,Yi,Thetai,UL,UR):
    t = 0
    r = 0.038
    L = 0.354
    dt = 0.1
    Xn=Xi
    Yn=Yi
    Thetan = 3.14 * Thetai / 180
    # Xi, Yi,Thetai: Input point's coordinates
    # Xs, Ys: Start point coordinates for plot function
    # Xn, Yn, Thetan: End point coordintes
    D=0
    while t<1:
        t = t + dt
        Xs = Xn
        Ys = Yn
        Xn += 0.5*r * (UL + UR) * math.cos(Thetan) * dt
        Yn += 0.5*r * (UL + UR) * math.sin(Thetan) * dt
        Thetan += (r / L) * (UR - UL) * dt
        
        # Draw line segment from start point to end point
        pygame.draw.line(screen, blue, (Xs*screen_width, (1-Ys)*screen_height), 
                         (Xn*screen_width, (1-Yn)*screen_height), 2)
        
    Thetan = 180 * (Thetan) / 3.14
    return Xn, Yn, Thetan, D

# List of actions (left and right wheel velocities)
actions=[[5,5], [10,10],[5,0],[0,5],[5,10],[10,5]]

# Initialize starting coordinates and orientation angle
X = 0
Y = 0
theta = 45

# Loop through each action and plot the resulting path
for action in actions:
    X, Y, theta, D = plot_curve(X, Y, theta, action[0], action[1])
for action in actions:
    X1,Y1,theta1,D1 = plot_curve(X,Y,theta,action[0],action[1])

# Update the display and wait for user to close the window
pygame.display.update()
done = False
while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
            
# Quit pygame
pygame.quit()